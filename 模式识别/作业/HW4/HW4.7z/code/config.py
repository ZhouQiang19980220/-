config = dict()
config['n_epochs'] = 1000
config['optimizer'] = "SGD"
config['batch_size'] = 1
config['lr'] = 0.1

config['hidden_channels'] = 5